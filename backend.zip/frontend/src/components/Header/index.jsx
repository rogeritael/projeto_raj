export function Header(){
    return (
        <header>
            <h1>Mundo Pokemon</h1> 
            <nav>
                <ul>
                    <li><a href="/mapa">Mapa</a></li>
                    <li><a href="/meus-pokemons">Meus Pokémons</a></li> 
                    <li><a href="/pokedex">Pokédex</a></li> 
                </ul>
            </nav>
        </header>
    )
}