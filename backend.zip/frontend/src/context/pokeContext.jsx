import { createContext, useState } from "react";

export const Context = createContext();

export function PokeProvider({children}){
    const [isModalOpen, setIsModalOpen] = useState(false)
    const [modalName, setModalName] = useState('')
    const [modalImage, setModalImage] = useState('')

    return (
        <Context.Provider value={{ isModalOpen, setIsModalOpen, modalName, setModalName, modalImage, setModalImage }}>
            {children}
        </Context.Provider>
    )
}